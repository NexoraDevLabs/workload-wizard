# Glossary

Project-specific terminology.
