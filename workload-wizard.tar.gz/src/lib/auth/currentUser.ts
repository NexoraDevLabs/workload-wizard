'use server';

import { currentUser } from '@clerk/nextjs/server';

export async function getCurrentUserDetails() {
  const user = await currentUser();

  if (!user) return null;

  return {
    id: user.id,
    email: user.emailAddresses[0]?.emailAddress,
    fullName: user.firstName + ' ' + user.lastName,
    organisationId: user.publicMetadata?.organisationId as string | undefined,
    role: user.publicMetadata?.role as string | undefined,
  };
}

/**
 * Gets current user and throws if they don't have an organisationId
 * Use this for actions that require organisation context
 */
export async function getUserOrgOrThrow() {
  const user = await currentUser();

  if (!user) {
    throw new Error('Unauthorised: User not authenticated');
  }

  const organisationId = user.publicMetadata?.organisationId as
    | string
    | undefined;

  if (!organisationId) {
    throw new Error('Unauthorised: User must be assigned to an organisation');
  }

  return {
    id: user.id,
    email: user.emailAddresses[0]?.emailAddress,
    fullName: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
    organisationId,
    role: user.publicMetadata?.role as string | undefined,
  };
}

/**
 * Gets current user and throws if they don't have an organisationId
 * Also validates that the user's organisationId matches the provided organisationId
 * Use this for actions that require specific organisation access
 */
export async function getUserOrgOrThrowWithValidation(
  requiredOrganisationId: string
) {
  const user = await getUserOrgOrThrow();

  if (user.organisationId !== requiredOrganisationId) {
    throw new Error('Unauthorised: Access denied to this organisation');
  }

  return user;
}

// Permission utility functions moved to src/lib/auth/permissions.ts
